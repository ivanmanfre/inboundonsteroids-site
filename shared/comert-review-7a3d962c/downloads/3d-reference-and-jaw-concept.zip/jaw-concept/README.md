# Right jaw contour v13: v11's front width, less thickness elsewhere

Status: exploratory contour reference. **Not a manufacturing design.** Like v12, it is a target
outer surface plus a thickness-over-bone map for the designer to rebuild in CAD.

## Files

| File | What it is |
|---|---|
| `right-contour-v13.stl` | v13 (built 2026-10-16 19:14, sha256 `66a0fb6aa6bc44cb…`). Watertight, one piece. |
| `contour-comparison-v13.blend` | Bone, v11, v12, v13, left in place, left mirrored (same frame), left mirrored (corner-aligned). One collection each; click the eye icon to toggle. Opens showing bone + v13. |
| `comparison-v13.html` | v11 / v13 / left side by side in five views, the "where material comes off" map, and the numbers. |
| `img/*.jpg` | Front, below, oblique, back and side renders (v11, v13, mirrored left), same camera and light as v11/v12. `img/removed-map.jpg` = removal map v12 vs v13. |
| `out/verification.json` | Every number below. `out/build.json` = build log. |
| `tmp/right-D8.0.stl` | A slightly thinner alternate (see "Trade-off"). |
| `build.py`, `verify13.py`, `render.py` | Rebuild: `python3.10 build.py 10 main`, `python3.10 verify13.py`, `blender -b -P render.py`. |

v11 and v12 were not touched.

## What changed from v12

v12 thinned "straight out from the surface". At the jaw corner that direction points mostly
sideways, so v12 removed **width** (front outline 3.1 mm inside the left), not just thickness.

v13 finds, at every height, the point where v11 sticks out furthest sideways (that point sets the
front outline). There v13 = v11. Moving forward or back from it, v13 fades smoothly toward v12's
thinner skin (Gaussian fade, 10 mm). Inner surface, footprint, edges, wrap and back edge are v11's.

## Front width (the thing Ivan asked to keep)

| Height above the corner | Left | v11 | **v13** |
|---|---|---|---|
| 0 mm | 56.87 | 57.29 | **57.27** |
| 4 mm | 57.73 | 57.79 | **57.77** |
| 8 mm | 58.17 | 58.03 | **58.01** |
| 12 mm | 58.13 | 57.94 | **57.93** |
| 16 mm | 57.28 | 57.32 | **57.31** |

v13 is within 0.04 mm of v11 at every height (h 4–16 mean vs left: v11 −0.03, v13 −0.05 mm).

## Thickness (mm, straight out from the surface)

| | v11 | **v13** | v12 | Left (mirrored) | Right today |
|---|---|---|---|---|---|
| Max | 8.59 | **8.53** | 6.57 | 5.50 | 5.82 |
| Mean | 3.63 | **3.48** | 2.95 | 2.29 | 2.55 |
| Gonial angle | 5.08 | **4.78** | 3.74 | 2.21 | 3.20 |
| Mid ramus | 4.15 | **3.97** | 3.32 | 2.10 | 2.63 |
| Mid body | 2.48 | **2.47** | 2.45 | 2.70 | 2.00 |
| Volume (cm³) | 4.13 | **3.97** | 3.02 | 2.30 | 2.39 |

## Why v13 is only a little thinner

This is the main finding, and it limits any "same width, less thickness" version.

- **At the corner, thickness is width.** The implant row at the corner is only about 20 mm across,
  and its widest point sits in the middle of it. v12's big cut (4–5 mm) was right on that point
  (see `img/removed-map.jpg`). Keep the width there and most of that cut has to come back.
- **Cutting harder next to the kept line makes a crest.** A first v13 that faded over 1–2.5 mm kept
  the width but left a ridge along the width line: skin roughness 0.16–0.32 vs v11 0.042. That's
  worse than the "feather" version dropped earlier for roughness (0.113).
- **v11's outer surface is already inside the left almost everywhere.** In the same frame it sits
  1.4 mm inside the left at the corner and 1.3 mm inside at mid ramus. It sits outside on only
  about 10–15% of the shared area: small patches low at the back and along the front tail.
  Its extra material, compared with the left, fills the gap from the right bone sitting about
  1.9 mm further in. It isn't extra bulk on the outside.

So "too much material" mostly shows up as **implant thickness over bone**, not as a fuller outer
shape. Taking it off without losing width is only possible where it isn't needed for width, and
that's only about 0.15–0.25 cm³.

## Trade-off (fade width)

| Fade | Volume | Gonial | Skin roughness (v11 0.042, v12 0.047) |
|---|---|---|---|
| 6 mm (earlier build, width 0.1 mm short) | 3.76 | 4.43 | 0.108 (too rough) |
| 8 mm (`tmp/right-D8.0.stl`) | 3.90 | 4.66 | 0.090 |
| **10 mm (v13)** | **3.97** | **4.78** | **0.071** |

## Transitions and fit (same as v11)

- Edges 1 mm in from the rim: 1.8 mm (front/upper), 1.7 mm (back/lower), same as v11.
- Inner surface to bone: median 0.42 mm, p95 2.42 mm; 13% not over bone (the lower-border wrap), same as v11.
- Bone overlap: 6 mm³, max 0.42 mm deep (the CT surface noise level), same as v11.
- Side outline: 0.15% of pixels changed; corner height unchanged (−80.42 mm).
- Mesh: watertight, consistent winding, one piece.
