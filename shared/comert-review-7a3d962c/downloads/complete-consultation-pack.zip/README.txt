IVAN MANFREDI - COMERT CONSULTATION REFERENCE PACK - 23 OCT 2026
For Dr Comert and the implant designer. Patient-prepared references for independent treating-team review.

START HERE
Open consultation-offline.html for the interactive handoff. Open source-index.json and manifest.json for source records, file roles, sizes and SHA-256 checksums. The four raw DICOM archives are NOT inside this reference pack. They are included in the separate complete download, and are linked in ct-studies/scan-index.html.

CONTENTS
rhinoplasty: V1-V8 appearance views and independent nostril alternatives; no registered 3D nose CAD. fat-and-lift: illustrative appearance comparisons and CT figures. ct-and-implants: CT/design comparison figures and existing design record. jaw-concept: current, A right-width, and B composite photo references. 3d-reference: existing CT-derived surfaces, masseter arrays, and registered chin/infraorbital references. The retired 2022-position bilateral photo trial and exploratory jaw STL/Blender exports are excluded from this active pack.

LIMITS
B is a composite: A right half plus an earlier left-inward half. It is not validated final bilateral CAD or a height target. Under-eye and upper-lid alternatives remain independent. Morphs are illustrations, not surgical predictions or treatment recommendations. No graft volume is prescribed. No CAD here is manufacturing-ready. CT segmentation, tissue boundaries, alignment and side orientation require independent verification. Registered design surfaces are not original manufacturer CAD. Do not infer muscle attachment, capsule, healthy operative bone, cut margins or screw paths from these exports. Historical recovered records remain at the separate source host.
