Rhinoplasty material: the displayed baseline is V1, an appearance preference only.
No 3D operative nose CAD or validated surgical outcome model exists in this package.
Nostril alternatives o1=smaller balanced, o2=intermediate, o3=longer teardrop, o4=rounder. They are independent older experiments, not selected treatment targets.
Preserve the liked profiles, bridge projection, nasal length and current tip rotation; no upward rotation requested.
Older video clips are secondary illustrations and can differ from the displayed V1; use the labeled V1 stills as the page baseline.